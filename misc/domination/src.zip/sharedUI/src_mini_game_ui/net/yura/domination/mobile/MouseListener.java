package net.yura.domination.mobile;

public interface MouseListener {
    void click(int x,int y);
}
