package net.yura.domination.mapstore;

/**
 * @author Yura Mamyrin
 */
public class Category {
    String id;
    String name;
    String iconURL;

    public String getIconURL() {
        return iconURL;
    }

    public void setIconURL(String iconURL) {
        this.iconURL = iconURL;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return id+" "+name;
    }
}
